#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author:songlin
@time: 2022/11/26 10:59
"""
import pytest


@pytest.mark.parametrize("name",["侧石2222","测试信息"])
def test_mm(name):
    print(name)